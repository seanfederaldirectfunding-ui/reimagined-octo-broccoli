// Stripe Payment Service
// Handles all Stripe payment processing and checkout functionality

const STRIPE_PUBLISHABLE_KEY =
  "pk_test_51SLAHrPLTUnnpuk4jdDZuszGTRyMap1cVPzlMZtkPSux8msR8UEkHknfOGnhylZg0tPyQtM6WZD8tyWwH9DW6NkR00DBHnbkkG"

export interface PaymentIntent {
  id: string
  amount: number
  currency: string
  status: "pending" | "processing" | "succeeded" | "failed"
  customerId: string
  customerName: string
  customerEmail: string
  description: string
  createdAt: Date
  metadata?: Record<string, string>
}

export interface Customer {
  id: string
  name: string
  email: string
  phone?: string
  address?: {
    line1: string
    line2?: string
    city: string
    state: string
    postal_code: string
    country: string
  }
}

class StripeService {
  private publishableKey: string

  constructor() {
    this.publishableKey = STRIPE_PUBLISHABLE_KEY
  }

  // Get Stripe publishable key
  getPublishableKey(): string {
    return this.publishableKey
  }

  // Create a payment intent (simulated for now)
  async createPaymentIntent(
    amount: number,
    currency = "usd",
    customer: Customer,
    description: string,
    metadata?: Record<string, string>,
  ): Promise<PaymentIntent> {
    try {
      console.log("[v0] Creating payment intent:", { amount, currency, customer, description })

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const paymentIntent: PaymentIntent = {
        id: `pi_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        amount,
        currency,
        status: "pending",
        customerId: customer.id,
        customerName: customer.name,
        customerEmail: customer.email,
        description,
        createdAt: new Date(),
        metadata,
      }

      // Store in localStorage
      const payments = this.getPayments()
      payments.push(paymentIntent)
      localStorage.setItem("stripe_payments", JSON.stringify(payments))

      console.log("[v0] Payment intent created:", paymentIntent)
      return paymentIntent
    } catch (error) {
      console.error("[v0] Error creating payment intent:", error)
      throw new Error("Failed to create payment intent")
    }
  }

  // Process a payment (simulated)
  async processPayment(
    paymentIntentId: string,
    paymentMethod: "card" | "ach" | "bank_transfer",
  ): Promise<PaymentIntent> {
    try {
      console.log("[v0] Processing payment:", { paymentIntentId, paymentMethod })

      // Simulate processing delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const payments = this.getPayments()
      const payment = payments.find((p) => p.id === paymentIntentId)

      if (!payment) {
        throw new Error("Payment intent not found")
      }

      // Simulate 95% success rate
      const success = Math.random() > 0.05

      payment.status = success ? "succeeded" : "failed"
      payment.metadata = {
        ...payment.metadata,
        paymentMethod,
        processedAt: new Date().toISOString(),
      }

      localStorage.setItem("stripe_payments", JSON.stringify(payments))

      console.log("[v0] Payment processed:", payment)
      return payment
    } catch (error) {
      console.error("[v0] Error processing payment:", error)
      throw new Error("Failed to process payment")
    }
  }

  // Get all payments
  getPayments(): PaymentIntent[] {
    try {
      const stored = localStorage.getItem("stripe_payments")
      return stored ? JSON.parse(stored) : []
    } catch (error) {
      console.error("[v0] Error getting payments:", error)
      return []
    }
  }

  // Get payment by ID
  getPaymentById(id: string): PaymentIntent | null {
    const payments = this.getPayments()
    return payments.find((p) => p.id === id) || null
  }

  // Get payments by customer
  getPaymentsByCustomer(customerId: string): PaymentIntent[] {
    const payments = this.getPayments()
    return payments.filter((p) => p.customerId === customerId)
  }

  // Refund a payment (simulated)
  async refundPayment(paymentIntentId: string, amount?: number): Promise<PaymentIntent> {
    try {
      console.log("[v0] Refunding payment:", { paymentIntentId, amount })

      await new Promise((resolve) => setTimeout(resolve, 1500))

      const payments = this.getPayments()
      const payment = payments.find((p) => p.id === paymentIntentId)

      if (!payment) {
        throw new Error("Payment intent not found")
      }

      if (payment.status !== "succeeded") {
        throw new Error("Can only refund succeeded payments")
      }

      payment.metadata = {
        ...payment.metadata,
        refunded: "true",
        refundAmount: (amount || payment.amount).toString(),
        refundedAt: new Date().toISOString(),
      }

      localStorage.setItem("stripe_payments", JSON.stringify(payments))

      console.log("[v0] Payment refunded:", payment)
      return payment
    } catch (error) {
      console.error("[v0] Error refunding payment:", error)
      throw new Error("Failed to refund payment")
    }
  }
}

export const stripeService = new StripeService()
