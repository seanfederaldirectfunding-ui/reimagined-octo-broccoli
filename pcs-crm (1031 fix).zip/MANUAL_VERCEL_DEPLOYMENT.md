# Manual Vercel Deployment - Step by Step Guide

## STEP 1: Download Your Project from v0

1. Look at the TOP RIGHT corner of your v0 screen
2. Find the three dots icon (⋮) or menu button
3. Click it to open the menu
4. Select "Download ZIP"
5. Save the file (it will be named something like "pcs-crm.zip")
6. Remember where you saved it (usually Downloads folder)

---

## STEP 2: Go to Vercel

1. Open a new browser tab
2. Go to: **https://vercel.com/login**
3. Sign in with your account

---

## STEP 3: Create New Project

After logging in, you should see your dashboard. Now:

1. Look for a button that says **"Add New..."** or **"New Project"** (usually top right)
2. Click it
3. You'll see a dropdown menu - select **"Project"**

---

## STEP 4: Import Your Project

You should now see a page titled "Import Git Repository" or "Let's build something new"

**OPTION A - If you see "Import Git Repository":**
1. Look for a tab or link that says **"Deploy from ZIP"** or **"Upload"**
2. Click it
3. You'll see a file upload area

**OPTION B - If you see a file upload area directly:**
1. You're in the right place!

**OPTION C - If you don't see either:**
1. Go directly to: **https://vercel.com/new**
2. This should take you to the import page

---

## STEP 5: Upload Your ZIP File

1. You should see a box that says "Drag and drop your project folder here" or similar
2. Click the **"Browse"** button (or drag your ZIP file into the box)
3. Navigate to where you saved the ZIP file (usually Downloads)
4. Select the ZIP file
5. Click "Open"

---

## STEP 6: Configure Project (IMPORTANT)

After uploading, Vercel will show you a configuration screen:

1. **Project Name**: You can change this to "pcs-crm" or leave it as is
2. **Framework Preset**: Should automatically detect "Next.js" - leave it
3. **Root Directory**: Leave as "./" (default)
4. **Build Command**: Leave as default
5. **Output Directory**: Leave as default
6. **Install Command**: Leave as default

**IMPORTANT - Environment Variables:**
Scroll down and look for "Environment Variables" section:

Add these variables one by one:

| Name | Value |
|------|-------|
| NEXT_PUBLIC_VOIP_SERVER | amn.sip.ssl7.net |
| NEXT_PUBLIC_VOIP_USERNAME | 201640 |
| MAILGUN_API_KEY | 2d9c7386bb7d9b810b322c9f89baeb80-653fadca-da66fd39 |
| MAILGUN_DOMAIN | (your mailgun domain) |
| NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY | pk_test_51SLAHrPLTUnnpuk4jdDZuszGTRyMap1cVPzlMZtkPSux8msR8UEkHknfOGnhylZg0tPyQtM6WZD8tyWwH9DW6NkR00DBHnbkkG |

To add each variable:
- Click "Add" or "Add Environment Variable"
- Type the Name in the first box
- Type the Value in the second box
- Click "Add" to confirm

---

## STEP 7: Deploy

1. After adding environment variables, scroll to the bottom
2. Click the big **"Deploy"** button
3. Wait for deployment (usually 2-5 minutes)
4. You'll see a progress screen with logs

---

## STEP 8: Success!

When deployment finishes:
1. You'll see a success screen with confetti animation
2. You'll get a URL like: `pcs-crm-xyz123.vercel.app`
3. Click "Visit" to see your live site

---

## STEP 9: Add Your Custom Domain (pcs-pcrm.com)

1. From the success screen, click "Continue to Dashboard"
2. Click on your project name
3. Click "Settings" tab at the top
4. Click "Domains" in the left sidebar
5. Type "pcs-pcrm.com" in the input box
6. Click "Add"
7. Follow the DNS instructions to point your domain

---

## Troubleshooting

**If you don't see the upload option:**
- Try going directly to: https://vercel.com/new
- Make sure you're logged in
- Try a different browser (Chrome recommended)

**If upload fails:**
- Make sure the ZIP file is not corrupted
- Try extracting the ZIP first, then upload the folder instead
- Check your internet connection

**If build fails:**
- Check the build logs for errors
- Make sure all environment variables are added correctly
- Contact me and share the error message

---

## Need Help?

If you get stuck at any step, tell me:
1. Which step number you're on
2. What you see on your screen
3. Any error messages

I'll guide you through it!
