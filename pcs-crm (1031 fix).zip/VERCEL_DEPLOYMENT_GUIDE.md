# PAGE CRM - Vercel Deployment Guide

## Quick Deploy (2 Minutes)

### Step 1: Deploy from v0
1. Click the **"Publish"** button in the top right corner of v0
2. Select **"Deploy to Vercel"**
3. Sign in with your GitHub account (or create one - it's free)
4. Click **"Deploy"**
5. Wait 2-3 minutes for deployment to complete
6. Your site will be live at: `https://your-project-name.vercel.app`

### Step 2: Add Environment Variables
After deployment, add these environment variables in Vercel:

1. Go to your project in Vercel Dashboard
2. Click **Settings** → **Environment Variables**
3. Add the following:

\`\`\`env
# VoIP Configuration (Already set in v0)
NEXT_PUBLIC_VOIP_SERVER=your_voip_server
NEXT_PUBLIC_VOIP_USERNAME=your_username

# Email (Mailgun - Already configured)
MAILGUN_API_KEY=2d9c7386bb7d9b810b322c9f89baeb80-653fadca-da66fd39
MAILGUN_DOMAIN=your-domain.mailgun.org

# Stripe (Already configured)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51SLAHrPLTUnnpuk4jdDZuszGTRyMap1cVPzlMZtkPSux8msR8UEkHknfOGnhylZg0tPyQtM6WZD8tyWwH9DW6NkR00DBHnbkkG

# WhatsApp (Optional)
WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id

# Signal (Optional)
SIGNAL_PHONE_NUMBER=your_signal_number
\`\`\`

4. Click **Save**
5. Vercel will automatically redeploy with the new variables

### Step 3: Connect Your GoDaddy Domain (Optional)

If you want to use your own domain from GoDaddy:

1. In Vercel Dashboard, go to **Settings** → **Domains**
2. Click **Add Domain**
3. Enter your domain (e.g., `yourcompany.com`)
4. Vercel will show you DNS records to add

5. Go to GoDaddy DNS Management:
   - Log into GoDaddy
   - Go to **My Products** → **DNS**
   - Add the DNS records Vercel provided:
     - Type: `A` Record
     - Name: `@`
     - Value: `76.76.21.21` (Vercel's IP)
     
     - Type: `CNAME` Record
     - Name: `www`
     - Value: `cname.vercel-dns.com`

6. Wait 24-48 hours for DNS propagation
7. Your site will be live at your custom domain!

## Alternative: Manual GitHub Deployment

If you prefer more control:

### Step 1: Download and Push to GitHub
1. Download the ZIP file from v0 (three dots → Download ZIP)
2. Extract the files
3. Create a new GitHub repository at https://github.com/new
4. Push the code:

\`\`\`bash
cd your-project-folder
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/your-repo.git
git push -u origin main
\`\`\`

### Step 2: Import to Vercel
1. Go to https://vercel.com/new
2. Click **Import Git Repository**
3. Select your GitHub repository
4. Click **Deploy**
5. Add environment variables (see Step 2 above)

## Post-Deployment Checklist

- [ ] Site is live and accessible
- [ ] Login works (test with: sean.federaldirectfunding.@gmail.com / Rasta4iva!)
- [ ] Dialer loads with all 3 modes visible
- [ ] Soft phone connects to VoIP.ms
- [ ] CRM tabs all load correctly
- [ ] Bulk texter interface works
- [ ] SMS response panel displays
- [ ] Stripe checkout loads
- [ ] Phone sync system is accessible in settings
- [ ] Social platform manager is accessible in settings

## Troubleshooting

### Issue: Environment variables not working
**Solution:** Make sure you added them in Vercel Dashboard → Settings → Environment Variables, then redeploy

### Issue: API routes returning 404
**Solution:** Vercel automatically handles Next.js API routes. Check that your routes are in the `app/api/` folder

### Issue: Build fails
**Solution:** Check the build logs in Vercel. Common issues:
- Missing dependencies (check package.json)
- TypeScript errors (run `npm run build` locally first)

### Issue: Custom domain not working
**Solution:** 
- Verify DNS records in GoDaddy match Vercel's requirements
- Wait 24-48 hours for DNS propagation
- Use https://dnschecker.org to verify DNS propagation

## Performance Optimization

Vercel automatically provides:
- Global CDN (fast worldwide)
- Automatic HTTPS/SSL
- Image optimization
- Edge caching
- DDoS protection
- 99.99% uptime SLA

## Monitoring

Access your deployment analytics:
1. Go to Vercel Dashboard
2. Click on your project
3. View **Analytics** tab for:
   - Page views
   - Response times
   - Error rates
   - Geographic distribution

## Support

- Vercel Documentation: https://vercel.com/docs
- Vercel Support: https://vercel.com/support
- Community: https://github.com/vercel/next.js/discussions

## Cost

**Free Tier Includes:**
- Unlimited deployments
- 100GB bandwidth/month
- Automatic SSL
- Custom domains
- Analytics

**If you exceed free tier:**
- Pro plan: $20/month (1TB bandwidth)
- Only pay if you need more resources

---

**Your PAGE CRM is now ready for production deployment on Vercel!**
