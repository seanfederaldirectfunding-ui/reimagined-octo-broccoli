"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

export function FiyahScraper() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Fiyah Scraper</h2>
      <Card className="bg-white/5 border-white/10 p-6">
        <div className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder="Enter URL to scrape..."
              className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-white/40"
            />
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
              <Search className="mr-2 h-4 w-4" />
              Scrape
            </Button>
          </div>
          <div className="text-center py-12 text-white/60">Enter a URL to start scraping data</div>
        </div>
      </Card>
    </div>
  )
}
