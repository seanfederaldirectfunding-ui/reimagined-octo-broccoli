"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Send, Phone, Video, MoreVertical } from "lucide-react"

interface MessagingCenterProps {
  user: any
}

const conversations = [
  { id: 1, name: "John Anderson", lastMessage: "Thanks for the follow-up!", time: "2m ago", unread: 2, avatar: "JA" },
  { id: 2, name: "Sarah Miller", lastMessage: "Can we schedule a call?", time: "15m ago", unread: 0, avatar: "SM" },
  { id: 3, name: "Mike Johnson", lastMessage: "Sounds good, talk soon", time: "1h ago", unread: 1, avatar: "MJ" },
  { id: 4, name: "Emma Davis", lastMessage: "I received the proposal", time: "3h ago", unread: 0, avatar: "ED" },
  { id: 5, name: "Robert Wilson", lastMessage: "Let me think about it", time: "5h ago", unread: 0, avatar: "RW" },
]

const messages = [
  { id: 1, sender: "them", text: "Hi! I received your email about the service", time: "10:30 AM" },
  { id: 2, sender: "me", text: "Great! Do you have any questions?", time: "10:32 AM" },
  { id: 3, sender: "them", text: "Yes, can you tell me more about pricing?", time: "10:35 AM" },
  { id: 4, sender: "me", text: "Of course! Our pricing starts at $99/month for the basic plan", time: "10:36 AM" },
  { id: 5, sender: "them", text: "Thanks for the follow-up!", time: "10:40 AM" },
]

export function MessagingCenter({ user }: MessagingCenterProps) {
  const [selectedConversation, setSelectedConversation] = useState(conversations[0])
  const [messageText, setMessageText] = useState("")

  const handleSendMessage = () => {
    if (messageText.trim()) {
      console.log("[v0] Sending message:", messageText)
      setMessageText("")
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Messages</h1>
        <p className="text-slate-600 mt-1">Communicate with your leads</p>
      </div>

      {/* Messaging Interface */}
      <div className="grid lg:grid-cols-3 gap-4 h-[calc(100vh-16rem)]">
        {/* Conversations List */}
        <Card className="border-slate-200 lg:col-span-1 overflow-hidden">
          <CardHeader className="border-b border-slate-200">
            <CardTitle className="text-lg">Conversations</CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-y-auto h-full">
            {conversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => setSelectedConversation(conv)}
                className={`w-full p-4 flex items-center gap-3 hover:bg-slate-50 transition-colors border-b border-slate-100 ${
                  selectedConversation.id === conv.id ? "bg-blue-50" : ""
                }`}
              >
                <Avatar className="h-12 w-12 bg-gradient-to-br from-blue-500 to-cyan-500">
                  <AvatarFallback className="text-white font-semibold">{conv.avatar}</AvatarFallback>
                </Avatar>
                <div className="flex-1 text-left min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="font-semibold text-slate-900 truncate">{conv.name}</p>
                    {conv.unread > 0 && (
                      <Badge className="bg-blue-600 text-white h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                        {conv.unread}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-600 truncate">{conv.lastMessage}</p>
                  <p className="text-xs text-slate-500 mt-1">{conv.time}</p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="border-slate-200 lg:col-span-2 flex flex-col overflow-hidden">
          {/* Chat Header */}
          <CardHeader className="border-b border-slate-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10 bg-gradient-to-br from-blue-500 to-cyan-500">
                  <AvatarFallback className="text-white font-semibold">{selectedConversation.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-slate-900">{selectedConversation.name}</h3>
                  <p className="text-xs text-slate-600">Active now</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline">
                  <Phone className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="outline">
                  <Video className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="ghost">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>

          {/* Messages */}
          <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === "me" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    message.sender === "me" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-900"
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <p className={`text-xs mt-1 ${message.sender === "me" ? "text-blue-100" : "text-slate-500"}`}>
                    {message.time}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>

          {/* Message Input */}
          <div className="border-t border-slate-200 p-4">
            <div className="flex gap-2">
              <Textarea
                placeholder="Type your message..."
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSendMessage()
                  }
                }}
                className="min-h-[60px] resize-none"
              />
              <Button onClick={handleSendMessage} className="bg-blue-600 hover:bg-blue-700 self-end">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
