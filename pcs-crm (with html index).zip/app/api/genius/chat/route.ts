import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message, history, context } = await request.json()

    console.log("[v0] GENIUS processing message:", message)

    // AI processing logic
    const response = await processGeniusRequest(message, history, context)

    return NextResponse.json({
      success: true,
      response: response.text,
      action: response.action,
      scheduledTask: response.scheduledTask,
    })
  } catch (error) {
    console.error("[v0] GENIUS chat error:", error)
    return NextResponse.json({ success: false, error: "Failed to process request" }, { status: 500 })
  }
}

async function processGeniusRequest(message: string, history: any[], context: any) {
  const lowerMessage = message.toLowerCase()

  // Email detection
  if (lowerMessage.includes("send email") || lowerMessage.includes("email")) {
    return {
      text: "I'll help you send that email. What's the recipient's email address and message content?",
      action: {
        type: "send_email",
        params: { message },
      },
    }
  }

  // Call detection
  if (lowerMessage.includes("call") || lowerMessage.includes("phone")) {
    return {
      text: "I can make that call for you. What's the phone number?",
      action: {
        type: "make_call",
        params: { message },
      },
    }
  }

  // SMS detection
  if (lowerMessage.includes("text") || lowerMessage.includes("sms")) {
    return {
      text: "I'll send that text message. What's the phone number and message?",
      action: {
        type: "send_sms",
        params: { message },
      },
    }
  }

  // Schedule detection
  if (lowerMessage.includes("schedule") || lowerMessage.includes("remind") || lowerMessage.includes("at")) {
    const scheduledTime = extractTime(message)
    return {
      text: `I've scheduled that task for ${scheduledTime.toLocaleString()}. I'll take care of it automatically.`,
      scheduledTask: {
        id: Date.now().toString(),
        description: message,
        scheduledTime,
        status: "pending",
        type: "custom",
      },
    }
  }

  // PageMaster detection
  if (lowerMessage.includes("website") || lowerMessage.includes("web") || lowerMessage.includes("navigate")) {
    return {
      text: "I'll use PageMaster to handle that web task. What's the URL?",
      action: {
        type: "use_pagemaster",
        params: { message },
      },
    }
  }

  // Lead management
  if (lowerMessage.includes("lead") || lowerMessage.includes("contact") || lowerMessage.includes("customer")) {
    return {
      text: "I can help you manage leads. What would you like to do?",
      action: {
        type: "manage_leads",
        params: { message },
      },
    }
  }

  // Default response
  return {
    text: "I understand. I can help you with emails, calls, SMS, scheduling tasks, web automation with PageMaster, and managing your CRM. What would you like me to do?",
  }
}

function extractTime(message: string): Date {
  const now = new Date()

  // Simple time extraction (can be enhanced with NLP)
  if (message.includes("tomorrow")) {
    now.setDate(now.getDate() + 1)
    now.setHours(9, 0, 0, 0)
  } else if (message.includes("next week")) {
    now.setDate(now.getDate() + 7)
    now.setHours(9, 0, 0, 0)
  } else {
    // Default to 1 hour from now
    now.setHours(now.getHours() + 1)
  }

  return now
}
