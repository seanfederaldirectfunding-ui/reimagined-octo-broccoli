# API Setup Guide for PAGE CRM

## Overview
This guide covers the environment variables needed for PAGE CRM. SMS is now handled by the standalone phone-sync system (no external service required).

---

## Required Environment Variables

### 1. Email Service - Mailgun (CONFIGURED ✓)
**Status:** API Key already integrated

**Environment Variables:**
\`\`\`
MAILGUN_API_KEY=2d9c7386bb7d9b810b322c9f89baeb80-653fadca-da66fd39
MAILGUN_DOMAIN=sandbox-123.mailgun.org (or your verified domain)
MAILGUN_FROM_EMAIL=noreply@federaldirectfunding.com
\`\`\`

**Setup:**
1. Go to https://app.mailgun.com
2. Verify your domain for production use (optional)
3. Update MAILGUN_DOMAIN with your verified domain

**Free Tier:** 5,000 emails/month for 3 months

---

### 2. VoIP Service - VoIP.ms (CONFIGURED ✓)
**Status:** Already configured

**Environment Variables:**
\`\`\`
NEXT_PUBLIC_VOIP_SERVER=your-voip-server.com
NEXT_PUBLIC_VOIP_USERNAME=your-username
\`\`\`

**Setup:** Already configured in your project

---

### 3. Payment Processing - Stripe (CONFIGURED ✓)
**Status:** Test key already integrated

**Environment Variables:**
\`\`\`
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51SLAHrPLTUnnpuk4jdDZuszGTRyMap1cVPzlMZtkPSux8msR8UEkHknfOGnhylZg0tPyQtM6WZD8tyWwH9DW6NkR00DBHnbkkG
\`\`\`

**Setup:** Already configured with test key. For production, replace with live key from Stripe dashboard.

---

### 4. SMS Service - Standalone Phone-Sync System (NO API NEEDED ✓)
**Status:** Uses your own phones - completely free

**No environment variables needed!**

**Setup:**
1. Go to Settings > Phone Manager in the CRM
2. Add your phones using the companion app
3. Phones will connect directly to the CRM
4. SMS sent through your existing cell service (free)

**Companion App Options:**
- Android: Use Tasker with AutoRemote plugin
- iOS: Use Shortcuts app with webhook automation
- Custom: Build simple app using provided API endpoints

---

## Optional Environment Variables (Multi-Channel Marketing)

### 5. WhatsApp Business API (Optional)
**Environment Variables:**
\`\`\`
WHATSAPP_BUSINESS_ACCOUNT_ID=your-account-id
WHATSAPP_ACCESS_TOKEN=your-access-token
WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
\`\`\`

**Setup:**
1. Go to https://business.facebook.com
2. Create WhatsApp Business Account
3. Get API credentials from Meta for Developers

**Free Tier:** 1,000 conversations/month

---

### 6. Telegram Bot API (Optional)
**Environment Variables:**
\`\`\`
TELEGRAM_BOT_TOKEN=your-bot-token
\`\`\`

**Setup:**
1. Open Telegram and search for @BotFather
2. Send /newbot and follow instructions
3. Copy the bot token provided

**Free Tier:** Completely free, unlimited messages

---

### 7. Signal API (Optional)
**Environment Variables:**
\`\`\`
SIGNAL_CLI_URL=http://localhost:8080 (your signal-cli REST API URL)
SIGNAL_PHONE_NUMBER=+1234567890
\`\`\`

**Setup:**
1. Install signal-cli: https://github.com/AsamK/signal-cli
2. Register your phone number
3. Run signal-cli in REST API mode
4. Point SIGNAL_CLI_URL to your instance

**Free Tier:** Completely free

---

### 8. Facebook Messenger API (Optional)
**Environment Variables:**
\`\`\`
FACEBOOK_PAGE_ACCESS_TOKEN=your-page-access-token
FACEBOOK_PAGE_ID=your-page-id
\`\`\`

**Setup:**
1. Go to https://developers.facebook.com
2. Create an app and add Messenger product
3. Connect your Facebook Page
4. Generate page access token

**Free Tier:** Free for standard messaging

---

### 9. Instagram Messaging API (Optional)
**Environment Variables:**
\`\`\`
INSTAGRAM_ACCESS_TOKEN=your-access-token
INSTAGRAM_BUSINESS_ACCOUNT_ID=your-account-id
\`\`\`

**Setup:**
1. Convert Instagram account to Business account
2. Connect to Facebook Page
3. Use Facebook Graph API to get access token
4. Enable Instagram Messaging in Meta for Developers

**Free Tier:** Free for standard messaging

---

### 10. Snapchat API (Optional)
**Environment Variables:**
\`\`\`
SNAPCHAT_CLIENT_ID=your-client-id
SNAPCHAT_CLIENT_SECRET=your-client-secret
\`\`\`

**Setup:**
1. Apply for Snapchat Business account
2. Request API access (requires approval)
3. Get credentials from Snapchat Business Manager

**Note:** Requires business account approval

---

## Summary of Required vs Optional

### REQUIRED (Already Configured):
- ✓ Mailgun (Email)
- ✓ VoIP.ms (Calling)
- ✓ Stripe (Payments)
- ✓ Standalone Phone-Sync (SMS) - No API needed

### OPTIONAL (For Additional Channels):
- WhatsApp Business API
- Telegram Bot API
- Signal API
- Facebook Messenger API
- Instagram Messaging API
- Snapchat API

---

## How to Add Environment Variables

### In v0 (Development):
1. Click the sidebar menu
2. Go to "Vars" section
3. Add each variable name and value
4. Save changes

### In Production (Vercel):
1. Go to your Vercel project dashboard
2. Navigate to Settings > Environment Variables
3. Add each variable
4. Redeploy your application

---

## Testing Your Setup

Go to **Settings > API Status** in the CRM to see which services are configured and test connectivity.
