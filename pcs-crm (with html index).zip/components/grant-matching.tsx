"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award } from "lucide-react"

export function GrantMatching() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Grant Matching</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[
          { name: "Small Business Grant 2025", amount: "$50,000", deadline: "Jan 15, 2025", match: 95 },
          { name: "Innovation Fund", amount: "$100,000", deadline: "Feb 1, 2025", match: 87 },
          { name: "Tech Startup Grant", amount: "$75,000", deadline: "Jan 30, 2025", match: 82 },
        ].map((grant, index) => (
          <Card key={index} className="bg-white/5 border-white/10 p-6">
            <div className="flex items-start justify-between mb-3">
              <Award className="h-6 w-6 text-cyan-400" />
              <Badge className="bg-green-500/20 text-green-400 border-green-400/30">{grant.match}% Match</Badge>
            </div>
            <h3 className="font-semibold text-white mb-2">{grant.name}</h3>
            <p className="text-2xl font-bold text-cyan-400 mb-2">{grant.amount}</p>
            <p className="text-sm text-white/60">Deadline: {grant.deadline}</p>
          </Card>
        ))}
      </div>
    </div>
  )
}
