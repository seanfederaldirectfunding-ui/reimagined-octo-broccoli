"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  Bot,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Play,
  Pause,
  CheckCircle,
  AlertCircle,
  Loader2,
  ExternalLink,
  Lock,
  Unlock,
  Download,
  Sparkles,
  Search,
} from "lucide-react"

interface PageMasterStep {
  id: string
  description: string
  location: string
  status: "pending" | "in-progress" | "waiting" | "completed" | "error"
  action?: string
  requiresConfirmation: boolean
}

export function PageMaster() {
  const [isOpen, setIsOpen] = useState(false)
  const [url, setUrl] = useState("")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [currentStep, setCurrentStep] = useState<PageMasterStep | null>(null)
  const [steps, setSteps] = useState<PageMasterStep[]>([])
  const [logs, setLogs] = useState<string[]>([])
  const [scrapeUrl, setScrapeUrl] = useState("")
  const [scrapeInstructions, setScrapeInstructions] = useState("")
  const [isScraping, setIsScraping] = useState(false)
  const [scrapedData, setScrapedData] = useState<any[]>([])
  const [scrapeProgress, setScrapeProgress] = useState("")

  const recognitionRef = useRef<any>(null)
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null)

  // Initialize Speech Recognition
  useEffect(() => {
    if (typeof window !== "undefined" && "webkitSpeechRecognition" in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = false

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[event.results.length - 1][0].transcript
        addLog(`[Voice Command] ${transcript}`)
        processVoiceCommand(transcript)
      }

      recognitionRef.current.onerror = (event: any) => {
        console.error("[v0] Speech recognition error:", event.error)
        addLog(`[Error] Voice recognition: ${event.error}`)
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `${new Date().toLocaleTimeString()} - ${message}`])
  }

  const speak = (text: string) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 1.0
      utterance.pitch = 1.0
      utterance.volume = 1.0

      utterance.onstart = () => setIsSpeaking(true)
      utterance.onend = () => setIsSpeaking(false)

      synthRef.current = utterance
      window.speechSynthesis.speak(utterance)
      addLog(`[Speaking] ${text}`)
    }
  }

  const toggleListening = () => {
    if (!recognitionRef.current) {
      addLog("[Error] Speech recognition not supported")
      return
    }

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
      addLog("[Voice] Stopped listening")
    } else {
      recognitionRef.current.start()
      setIsListening(true)
      addLog("[Voice] Started listening")
      speak("I'm listening for your commands")
    }
  }

  const toggleSpeaking = () => {
    if (isSpeaking && synthRef.current) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const processVoiceCommand = (command: string) => {
    const lowerCommand = command.toLowerCase()

    if (lowerCommand.includes("start") || lowerCommand.includes("begin")) {
      handleStart()
    } else if (lowerCommand.includes("pause") || lowerCommand.includes("stop")) {
      handlePause()
    } else if (lowerCommand.includes("continue") || lowerCommand.includes("resume")) {
      handleContinue()
    } else if (lowerCommand.includes("confirm") || lowerCommand.includes("yes")) {
      handleConfirm()
    } else {
      speak("I didn't understand that command. Try saying start, pause, continue, or confirm.")
    }
  }

  const handleStart = async () => {
    if (!url) {
      speak("Please enter a URL first")
      return
    }

    setIsRunning(true)
    setIsPaused(false)
    addLog(`[Starting] Navigating to ${url}`)
    speak(`Starting automation for ${url}`)

    try {
      // Call backend API to start automation
      const response = await fetch("/api/pagemaster/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, username, password }),
      })

      const data = await response.json()

      if (data.success) {
        setSteps(data.steps)
        processNextStep(data.steps[0])
      } else {
        addLog(`[Error] ${data.error}`)
        speak(`Error: ${data.error}`)
        setIsRunning(false)
      }
    } catch (error) {
      console.error("[v0] PageMaster start error:", error)
      addLog(`[Error] Failed to start automation`)
      speak("Failed to start automation")
      setIsRunning(false)
    }
  }

  const processNextStep = (step: PageMasterStep) => {
    setCurrentStep(step)
    addLog(`[Step] ${step.description}`)
    speak(`I'm now at ${step.location}. ${step.description}`)

    if (step.requiresConfirmation) {
      setIsPaused(true)
      speak("Please confirm to continue by clicking the confirm button or saying confirm")
    } else {
      // Auto-continue to next step after 2 seconds
      setTimeout(() => {
        handleContinue()
      }, 2000)
    }
  }

  const handlePause = () => {
    setIsPaused(true)
    addLog("[Paused] Automation paused")
    speak("Automation paused")
  }

  const handleContinue = async () => {
    if (!currentStep) return

    setIsPaused(false)
    addLog("[Continuing] Moving to next step")

    try {
      const response = await fetch("/api/pagemaster/continue", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stepId: currentStep.id }),
      })

      const data = await response.json()

      if (data.nextStep) {
        processNextStep(data.nextStep)
      } else if (data.completed) {
        handleComplete()
      }
    } catch (error) {
      console.error("[v0] PageMaster continue error:", error)
      addLog(`[Error] Failed to continue`)
    }
  }

  const handleConfirm = () => {
    if (currentStep?.requiresConfirmation) {
      addLog("[Confirmed] User confirmed action")
      speak("Confirmed. Continuing to next step")
      handleContinue()
    }
  }

  const handleComplete = () => {
    setIsRunning(false)
    setIsPaused(false)
    setCurrentStep(null)
    addLog("[Completed] Automation completed successfully")
    speak("Automation completed successfully. All tasks are done.")
  }

  const handleStartScraping = async () => {
    if (!scrapeUrl || !scrapeInstructions) {
      speak("Please enter both URL and instructions")
      return
    }

    setIsScraping(true)
    setScrapeProgress("Initializing web scraper...")
    addLog(`[Scraping] Starting data extraction from ${scrapeUrl}`)
    speak("Starting web scraping and data extraction")

    try {
      const response = await fetch("/api/pagemaster/scrape", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: scrapeUrl,
          instructions: scrapeInstructions,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setScrapedData(data.results)
        setScrapeProgress(`Extracted ${data.results.length} records successfully`)
        addLog(`[Success] Extracted ${data.results.length} records`)
        speak(`Successfully extracted ${data.results.length} records. Ready to export to CSV.`)
      } else {
        setScrapeProgress(`Error: ${data.error}`)
        addLog(`[Error] ${data.error}`)
        speak(`Error: ${data.error}`)
      }
    } catch (error) {
      console.error("[v0] Scraping error:", error)
      setScrapeProgress("Failed to scrape data")
      addLog("[Error] Failed to scrape data")
      speak("Failed to scrape data")
    } finally {
      setIsScraping(false)
    }
  }

  const handleExportCSV = () => {
    if (scrapedData.length === 0) {
      speak("No data to export")
      return
    }

    // Convert to CSV
    const headers = [
      "Business Name",
      "Owner Name",
      "Owner Email",
      "Company Email",
      "Owner Phone",
      "Company Phone",
      "WhatsApp",
      "Telegram",
      "Signal",
      "Facebook",
      "Instagram",
      "LinkedIn",
      "Twitter",
      "TikTok",
      "Snapchat",
    ]

    const csvContent = [
      headers.join(","),
      ...scrapedData.map((row) =>
        [
          row.businessName || "",
          row.ownerName || "",
          row.ownerEmail || "",
          row.companyEmail || "",
          row.ownerPhone || "",
          row.companyPhone || "",
          row.whatsapp || "",
          row.telegram || "",
          row.signal || "",
          row.facebook || "",
          row.instagram || "",
          row.linkedin || "",
          row.twitter || "",
          row.tiktok || "",
          row.snapchat || "",
        ]
          .map((field) => `"${String(field).replace(/"/g, '""')}"`)
          .join(","),
      ),
    ].join("\n")

    // Download CSV
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `scraped_data_${Date.now()}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    addLog(`[Export] Downloaded CSV with ${scrapedData.length} records`)
    speak(`CSV file downloaded with ${scrapedData.length} records`)
  }

  return (
    <>
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-24 z-40 gap-2 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white shadow-lg hover:shadow-xl transition-all duration-200 h-12 px-6"
        size="lg"
      >
        <Bot className="h-5 w-5" />
        <span className="font-semibold">PAGEMASTER</span>
      </Button>

      {/* PAGEMASTER Console - Opens from bottom */}
      {isOpen && (
        <div className="fixed bottom-0 left-0 right-0 z-50 bg-black/95 border-t border-cyan-500/30 backdrop-blur-lg shadow-2xl animate-in slide-in-from-bottom duration-300">
          <div className="container mx-auto p-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Bot className="h-6 w-6 text-cyan-400" />
                  <h2 className="text-xl font-bold text-white">PAGEMASTER AI</h2>
                </div>
                {isRunning && (
                  <Badge variant="outline" className="border-green-500 text-green-400">
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                    Running
                  </Badge>
                )}
                {isPaused && (
                  <Badge variant="outline" className="border-yellow-500 text-yellow-400">
                    Waiting for Confirmation
                  </Badge>
                )}
                {isScraping && (
                  <Badge variant="outline" className="border-purple-500 text-purple-400">
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                    Scraping
                  </Badge>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)} className="text-white">
                Close
              </Button>
            </div>

            {/* Tabs for Automation and Create Anything */}
            <Tabs defaultValue="automation" className="w-full">
              <TabsList className="bg-black/40 border border-cyan-500/30">
                <TabsTrigger value="automation" className="data-[state=active]:bg-cyan-500/20">
                  <Bot className="h-4 w-4 mr-2" />
                  Web Automation
                </TabsTrigger>
                <TabsTrigger value="scraper" className="data-[state=active]:bg-purple-500/20">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Create Anything
                </TabsTrigger>
              </TabsList>

              {/* Web Automation Tab */}
              <TabsContent value="automation" className="mt-4">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  {/* Control Panel */}
                  <Card className="bg-black/40 border-cyan-500/30 p-4 space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm text-cyan-400">Target URL</label>
                      <div className="flex gap-2">
                        <Input
                          value={url}
                          onChange={(e) => setUrl(e.target.value)}
                          placeholder="https://example.com"
                          className="bg-black/40 border-cyan-500/30 text-white"
                          disabled={isRunning}
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          className="border-cyan-500/30 bg-transparent"
                          disabled={isRunning}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-2">
                        <label className="text-sm text-cyan-400">Username</label>
                        <div className="flex gap-2">
                          <Input
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            placeholder="Optional"
                            className="bg-black/40 border-cyan-500/30 text-white"
                            disabled={isRunning}
                          />
                          <Button
                            variant="outline"
                            size="icon"
                            className="border-cyan-500/30 bg-transparent"
                            disabled={isRunning}
                          >
                            {username ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm text-cyan-400">Password</label>
                        <Input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Optional"
                          className="bg-black/40 border-cyan-500/30 text-white"
                          disabled={isRunning}
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      {!isRunning ? (
                        <Button onClick={handleStart} className="flex-1 bg-green-600 hover:bg-green-700">
                          <Play className="h-4 w-4 mr-2" />
                          Start
                        </Button>
                      ) : (
                        <>
                          <Button
                            onClick={handlePause}
                            className="flex-1 bg-yellow-600 hover:bg-yellow-700"
                            disabled={isPaused}
                          >
                            <Pause className="h-4 w-4 mr-2" />
                            Pause
                          </Button>
                          <Button
                            onClick={handleContinue}
                            className="flex-1 bg-blue-600 hover:bg-blue-700"
                            disabled={!isPaused}
                          >
                            <Play className="h-4 w-4 mr-2" />
                            Continue
                          </Button>
                        </>
                      )}
                    </div>

                    {currentStep?.requiresConfirmation && (
                      <Button onClick={handleConfirm} className="w-full bg-cyan-600 hover:bg-cyan-700">
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Confirm Action
                      </Button>
                    )}

                    <div className="flex gap-2">
                      <Button
                        onClick={toggleListening}
                        variant="outline"
                        className={`flex-1 ${isListening ? "border-red-500 text-red-400" : "border-cyan-500/30"}`}
                      >
                        {isListening ? <MicOff className="h-4 w-4 mr-2" /> : <Mic className="h-4 w-4 mr-2" />}
                        {isListening ? "Stop Listening" : "Voice Commands"}
                      </Button>
                      <Button
                        onClick={toggleSpeaking}
                        variant="outline"
                        className={`flex-1 ${isSpeaking ? "border-red-500 text-red-400" : "border-cyan-500/30"}`}
                      >
                        {isSpeaking ? <VolumeX className="h-4 w-4 mr-2" /> : <Volume2 className="h-4 w-4 mr-2" />}
                        {isSpeaking ? "Mute" : "Speaker"}
                      </Button>
                    </div>
                  </Card>

                  {/* Current Step Display */}
                  <Card className="bg-black/40 border-cyan-500/30 p-4">
                    <h3 className="text-lg font-semibold text-cyan-400 mb-4">Current Step</h3>
                    {currentStep ? (
                      <div className="space-y-3">
                        <div className="flex items-start gap-3">
                          {currentStep.status === "in-progress" && (
                            <Loader2 className="h-5 w-5 text-blue-400 animate-spin mt-1" />
                          )}
                          {currentStep.status === "waiting" && <AlertCircle className="h-5 w-5 text-yellow-400 mt-1" />}
                          {currentStep.status === "completed" && (
                            <CheckCircle className="h-5 w-5 text-green-400 mt-1" />
                          )}
                          <div className="flex-1">
                            <p className="text-white font-medium">{currentStep.description}</p>
                            <p className="text-sm text-cyan-400 mt-1">Location: {currentStep.location}</p>
                            {currentStep.action && (
                              <p className="text-sm text-gray-400 mt-1">Action: {currentStep.action}</p>
                            )}
                          </div>
                        </div>
                        {currentStep.requiresConfirmation && (
                          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded p-3">
                            <p className="text-sm text-yellow-400">
                              ⚠️ This step requires your confirmation. Click "Confirm Action" or say "confirm" to
                              continue.
                            </p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-gray-400">No active step. Start automation to begin.</p>
                    )}

                    {/* Steps Progress */}
                    {steps.length > 0 && (
                      <div className="mt-4 space-y-2">
                        <h4 className="text-sm font-semibold text-cyan-400">Progress</h4>
                        <div className="space-y-1">
                          {steps.map((step, index) => (
                            <div key={step.id} className="flex items-center gap-2 text-sm">
                              {step.status === "completed" && <CheckCircle className="h-4 w-4 text-green-400" />}
                              {step.status === "in-progress" && (
                                <Loader2 className="h-4 w-4 text-blue-400 animate-spin" />
                              )}
                              {step.status === "waiting" && <AlertCircle className="h-4 w-4 text-yellow-400" />}
                              {step.status === "pending" && (
                                <div className="h-4 w-4 rounded-full border-2 border-gray-600" />
                              )}
                              <span className={step.status === "completed" ? "text-gray-400" : "text-white"}>
                                {index + 1}. {step.description}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </Card>

                  {/* Activity Log */}
                  <Card className="bg-black/40 border-cyan-500/30 p-4">
                    <h3 className="text-lg font-semibold text-cyan-400 mb-4">Activity Log</h3>
                    <ScrollArea className="h-[300px]">
                      <div className="space-y-1">
                        {logs.map((log, index) => (
                          <p key={index} className="text-xs text-gray-300 font-mono">
                            {log}
                          </p>
                        ))}
                      </div>
                    </ScrollArea>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="scraper" className="mt-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Scraping Control Panel */}
                  <Card className="bg-black/40 border-purple-500/30 p-4 space-y-4">
                    <div className="flex items-center gap-2 mb-4">
                      <Sparkles className="h-5 w-5 text-purple-400" />
                      <h3 className="text-lg font-semibold text-purple-400">Create Anything</h3>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-purple-400">Target URL or Website</label>
                      <div className="flex gap-2">
                        <Input
                          value={scrapeUrl}
                          onChange={(e) => setScrapeUrl(e.target.value)}
                          placeholder="https://example.com or search query"
                          className="bg-black/40 border-purple-500/30 text-white"
                          disabled={isScraping}
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          className="border-purple-500/30 bg-transparent"
                          disabled={isScraping}
                        >
                          <Search className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-purple-400">What do you want to extract?</label>
                      <Textarea
                        value={scrapeInstructions}
                        onChange={(e) => setScrapeInstructions(e.target.value)}
                        placeholder="Example: Find all businesses in the construction industry with their contact info, owner names, emails, phone numbers, and social media handles"
                        className="bg-black/40 border-purple-500/30 text-white min-h-[120px]"
                        disabled={isScraping}
                      />
                    </div>

                    <div className="bg-purple-500/10 border border-purple-500/30 rounded p-3">
                      <p className="text-xs text-purple-300 mb-2">
                        <strong>Auto-extracted fields:</strong>
                      </p>
                      <div className="grid grid-cols-2 gap-1 text-xs text-purple-200">
                        <div>• Business Name</div>
                        <div>• Owner Name</div>
                        <div>• Owner Email</div>
                        <div>• Company Email</div>
                        <div>• Owner Phone</div>
                        <div>• Company Phone</div>
                        <div>• WhatsApp</div>
                        <div>• Telegram</div>
                        <div>• Signal</div>
                        <div>• Facebook</div>
                        <div>• Instagram</div>
                        <div>• LinkedIn</div>
                        <div>• Twitter</div>
                        <div>• TikTok</div>
                        <div>• Snapchat</div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={handleStartScraping}
                        className="flex-1 bg-purple-600 hover:bg-purple-700"
                        disabled={isScraping || !scrapeUrl || !scrapeInstructions}
                      >
                        {isScraping ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Scraping...
                          </>
                        ) : (
                          <>
                            <Sparkles className="h-4 w-4 mr-2" />
                            Start Scraping
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={handleExportCSV}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                        disabled={scrapedData.length === 0}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Export CSV
                      </Button>
                    </div>

                    {scrapeProgress && (
                      <div className="bg-black/40 border border-purple-500/30 rounded p-3">
                        <p className="text-sm text-purple-300">{scrapeProgress}</p>
                      </div>
                    )}
                  </Card>

                  {/* Scraped Data Preview */}
                  <Card className="bg-black/40 border-purple-500/30 p-4">
                    <h3 className="text-lg font-semibold text-purple-400 mb-4">
                      Extracted Data ({scrapedData.length} records)
                    </h3>
                    <ScrollArea className="h-[400px]">
                      {scrapedData.length > 0 ? (
                        <div className="space-y-3">
                          {scrapedData.map((record, index) => (
                            <div key={index} className="bg-black/40 border border-purple-500/20 rounded p-3 space-y-1">
                              <div className="flex items-center justify-between">
                                <p className="font-semibold text-white">{record.businessName || "N/A"}</p>
                                <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                                  #{index + 1}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-300">Owner: {record.ownerName || "N/A"}</p>
                              <div className="grid grid-cols-2 gap-1 text-xs text-gray-400">
                                {record.ownerEmail && <div>📧 {record.ownerEmail}</div>}
                                {record.companyEmail && <div>📧 {record.companyEmail}</div>}
                                {record.ownerPhone && <div>📞 {record.ownerPhone}</div>}
                                {record.companyPhone && <div>📞 {record.companyPhone}</div>}
                              </div>
                              <div className="flex flex-wrap gap-1 mt-2">
                                {record.whatsapp && (
                                  <Badge variant="outline" className="text-xs border-green-500/30 text-green-400">
                                    WhatsApp
                                  </Badge>
                                )}
                                {record.telegram && (
                                  <Badge variant="outline" className="text-xs border-blue-500/30 text-blue-400">
                                    Telegram
                                  </Badge>
                                )}
                                {record.signal && (
                                  <Badge variant="outline" className="text-xs border-indigo-500/30 text-indigo-400">
                                    Signal
                                  </Badge>
                                )}
                                {record.facebook && (
                                  <Badge variant="outline" className="text-xs border-blue-600/30 text-blue-300">
                                    Facebook
                                  </Badge>
                                )}
                                {record.instagram && (
                                  <Badge variant="outline" className="text-xs border-pink-500/30 text-pink-400">
                                    Instagram
                                  </Badge>
                                )}
                                {record.linkedin && (
                                  <Badge variant="outline" className="text-xs border-cyan-500/30 text-cyan-400">
                                    LinkedIn
                                  </Badge>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center">
                          <Search className="h-12 w-12 text-purple-400/30 mb-4" />
                          <p className="text-gray-400">No data extracted yet</p>
                          <p className="text-sm text-gray-500 mt-2">Enter a URL and instructions to start scraping</p>
                        </div>
                      )}
                    </ScrollArea>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}
    </>
  )
}
