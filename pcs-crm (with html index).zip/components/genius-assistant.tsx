"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import {
  Sparkles,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Calendar,
  Mail,
  Phone,
  MessageSquare,
  Bot,
  X,
  Minimize2,
  Maximize2,
} from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface ScheduledTask {
  id: string
  description: string
  scheduledTime: Date
  status: "pending" | "running" | "completed" | "failed"
  type: "email" | "call" | "sms" | "web-automation" | "custom"
}

export function GeniusAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<Message[]>([])
  const [scheduledTasks, setScheduledTasks] = useState<ScheduledTask[]>([])
  const [isProcessing, setIsProcessing] = useState(false)

  const recognitionRef = useRef<any>(null)
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const callPageMaster = async (params: any) => {
    console.log("[v0] GENIUS using PageMaster:", params)
    // Integration with PageMaster
    await fetch("/api/pagemaster/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    })
  }

  // Initialize Speech Recognition
  useEffect(() => {
    if (typeof window !== "undefined" && "webkitSpeechRecognition" in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = false

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[event.results.length - 1][0].transcript
        console.log("[v0] GENIUS heard:", transcript)
        setMessage(transcript)
        handleSendMessage(transcript)
      }

      recognitionRef.current.onerror = (event: any) => {
        console.error("[v0] GENIUS speech recognition error:", event.error)
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Check scheduled tasks
  useEffect(() => {
    const interval = setInterval(() => {
      checkScheduledTasks()
    }, 10000) // Check every 10 seconds

    return () => clearInterval(interval)
  }, [scheduledTasks])

  const speak = (text: string) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 1.1
      utterance.pitch = 1.1
      utterance.volume = 1.0
      utterance.voice = window.speechSynthesis.getVoices().find((voice) => voice.name.includes("Female")) || null

      utterance.onstart = () => setIsSpeaking(true)
      utterance.onend = () => setIsSpeaking(false)

      synthRef.current = utterance
      window.speechSynthesis.speak(utterance)
      console.log("[v0] GENIUS speaking:", text)
    }
  }

  const toggleListening = () => {
    if (!recognitionRef.current) return

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
      console.log("[v0] GENIUS stopped listening")
    } else {
      recognitionRef.current.start()
      setIsListening(true)
      console.log("[v0] GENIUS started listening")
      speak("Yes, I'm listening. How can I help you?")
    }
  }

  const toggleSpeaking = () => {
    if (isSpeaking && synthRef.current) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const handleSendMessage = async (text?: string) => {
    const messageText = text || message
    if (!messageText.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: messageText,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setMessage("")
    setIsProcessing(true)

    console.log("[v0] GENIUS processing:", messageText)

    try {
      // Call GENIUS AI backend
      const response = await fetch("/api/genius/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: messageText,
          history: messages,
          context: {
            scheduledTasks,
            availableFunctions: [
              "send_email",
              "make_call",
              "send_sms",
              "schedule_task",
              "use_pagemaster",
              "manage_leads",
              "create_application",
              "send_bulk_message",
            ],
          },
        }),
      })

      const data = await response.json()

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.response,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
      speak(data.response)

      // Handle actions
      if (data.action) {
        await executeAction(data.action)
      }

      // Handle scheduled tasks
      if (data.scheduledTask) {
        setScheduledTasks((prev) => [...prev, data.scheduledTask])
      }
    } catch (error) {
      console.error("[v0] GENIUS error:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "I apologize, but I encountered an error. Please try again.",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
      speak("I apologize, but I encountered an error. Please try again.")
    } finally {
      setIsProcessing(false)
    }
  }

  const executeAction = async (action: any) => {
    console.log("[v0] GENIUS executing action:", action)

    switch (action.type) {
      case "send_email":
        await sendEmail(action.params)
        break
      case "make_call":
        await makeCall(action.params)
        break
      case "send_sms":
        await sendSMS(action.params)
        break
      case "use_pagemaster":
        await callPageMaster(action.params)
        break
      case "manage_leads":
        await manageLeads(action.params)
        break
      default:
        console.log("[v0] GENIUS unknown action type:", action.type)
    }
  }

  const sendEmail = async (params: any) => {
    console.log("[v0] GENIUS sending email:", params)
    // Integration with email system
    await fetch("/api/genius/actions/email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    })
  }

  const makeCall = async (params: any) => {
    console.log("[v0] GENIUS making call:", params)
    // Integration with VoIP system
    await fetch("/api/genius/actions/call", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    })
  }

  const sendSMS = async (params: any) => {
    console.log("[v0] GENIUS sending SMS:", params)
    // Integration with SMS system
    await fetch("/api/genius/actions/sms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    })
  }

  const manageLeads = async (params: any) => {
    console.log("[v0] GENIUS managing leads:", params)
    // Integration with CRM leads system
    await fetch("/api/genius/actions/leads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    })
  }

  const checkScheduledTasks = () => {
    const now = new Date()
    scheduledTasks.forEach((task) => {
      if (task.status === "pending" && task.scheduledTime <= now) {
        executeScheduledTask(task)
      }
    })
  }

  const executeScheduledTask = async (task: ScheduledTask) => {
    console.log("[v0] GENIUS executing scheduled task:", task)
    setScheduledTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, status: "running" as const } : t)))

    try {
      await fetch("/api/genius/execute-task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId: task.id }),
      })

      setScheduledTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, status: "completed" as const } : t)))

      speak(`Task completed: ${task.description}`)
    } catch (error) {
      console.error("[v0] GENIUS task execution error:", error)
      setScheduledTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, status: "failed" as const } : t)))
    }
  }

  return (
    <>
      {/* Floating GENIUS Icon */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="h-16 w-16 rounded-full bg-gradient-to-br from-purple-500 via-pink-500 to-rose-500 hover:from-purple-600 hover:via-pink-600 hover:to-rose-600 shadow-2xl shadow-purple-500/50 transition-all duration-300 hover:scale-110"
          size="icon"
        >
          <div className="relative">
            <Sparkles className="h-8 w-8 text-white" />
            {isListening && <div className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full animate-pulse" />}
            {scheduledTasks.filter((t) => t.status === "pending").length > 0 && (
              <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center bg-blue-500 text-white text-xs">
                {scheduledTasks.filter((t) => t.status === "pending").length}
              </Badge>
            )}
          </div>
        </Button>
      </div>

      {/* GENIUS Chat Interface */}
      {isOpen && (
        <div
          className={`fixed bottom-24 right-6 z-50 w-96 transition-all duration-300 ${
            isMinimized ? "h-14" : "h-[600px]"
          }`}
        >
          <Card className="h-full bg-gradient-to-br from-purple-900/95 via-pink-900/95 to-rose-900/95 backdrop-blur-xl border-purple-500/30 shadow-2xl flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-purple-500/30">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                    <Sparkles className="h-6 w-6 text-white" />
                  </div>
                  {isListening && (
                    <div className="absolute -bottom-1 -right-1 h-3 w-3 bg-red-500 rounded-full animate-pulse" />
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-white">GENIUS</h3>
                  <p className="text-xs text-purple-200">Your AI Business Assistant</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="text-white hover:bg-purple-500/20"
                >
                  {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-purple-500/20"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {messages.length === 0 && (
                      <div className="text-center py-8">
                        <Sparkles className="h-12 w-12 text-purple-300 mx-auto mb-4" />
                        <p className="text-purple-200 text-sm">
                          Hi! I'm GENIUS, your AI business assistant.
                          <br />I can help you with emails, calls, scheduling, and more!
                        </p>
                      </div>
                    )}
                    {messages.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            msg.role === "user"
                              ? "bg-purple-500 text-white"
                              : "bg-black/40 text-purple-100 border border-purple-500/30"
                          }`}
                        >
                          <p className="text-sm">{msg.content}</p>
                          <p className="text-xs opacity-70 mt-1">{msg.timestamp.toLocaleTimeString()}</p>
                        </div>
                      </div>
                    ))}
                    {isProcessing && (
                      <div className="flex justify-start">
                        <div className="bg-black/40 text-purple-100 border border-purple-500/30 rounded-lg p-3">
                          <div className="flex items-center gap-2">
                            <div className="flex gap-1">
                              <div
                                className="h-2 w-2 bg-purple-400 rounded-full animate-bounce"
                                style={{ animationDelay: "0ms" }}
                              />
                              <div
                                className="h-2 w-2 bg-purple-400 rounded-full animate-bounce"
                                style={{ animationDelay: "100ms" }}
                              />
                              <div
                                className="h-2 w-2 bg-purple-400 rounded-full animate-bounce"
                                style={{ animationDelay: "200ms" }}
                              />
                            </div>
                            <span className="text-xs">GENIUS is thinking...</span>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Scheduled Tasks */}
                {scheduledTasks.length > 0 && (
                  <div className="px-4 py-2 border-t border-purple-500/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="h-4 w-4 text-purple-300" />
                      <span className="text-xs text-purple-200 font-semibold">Scheduled Tasks</span>
                    </div>
                    <div className="space-y-1 max-h-20 overflow-y-auto">
                      {scheduledTasks.slice(-3).map((task) => (
                        <div
                          key={task.id}
                          className="flex items-center justify-between text-xs bg-black/20 rounded p-2"
                        >
                          <div className="flex items-center gap-2">
                            {task.type === "email" && <Mail className="h-3 w-3 text-purple-300" />}
                            {task.type === "call" && <Phone className="h-3 w-3 text-purple-300" />}
                            {task.type === "sms" && <MessageSquare className="h-3 w-3 text-purple-300" />}
                            {task.type === "web-automation" && <Bot className="h-3 w-3 text-purple-300" />}
                            <span className="text-purple-200 truncate max-w-[200px]">{task.description}</span>
                          </div>
                          <Badge
                            variant="outline"
                            className={`text-xs ${
                              task.status === "completed"
                                ? "border-green-500 text-green-400"
                                : task.status === "running"
                                  ? "border-blue-500 text-blue-400"
                                  : task.status === "failed"
                                    ? "border-red-500 text-red-400"
                                    : "border-purple-500 text-purple-400"
                            }`}
                          >
                            {task.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Input */}
                <div className="p-4 border-t border-purple-500/30">
                  <div className="flex gap-2 mb-2">
                    <Button
                      onClick={toggleListening}
                      variant="outline"
                      size="sm"
                      className={`flex-1 ${
                        isListening
                          ? "border-red-500 text-red-400 bg-red-500/10"
                          : "border-purple-500/30 text-purple-200 bg-transparent"
                      }`}
                    >
                      {isListening ? <MicOff className="h-4 w-4 mr-2" /> : <Mic className="h-4 w-4 mr-2" />}
                      {isListening ? "Stop" : "Voice"}
                    </Button>
                    <Button
                      onClick={toggleSpeaking}
                      variant="outline"
                      size="sm"
                      className={`flex-1 ${
                        isSpeaking
                          ? "border-red-500 text-red-400 bg-red-500/10"
                          : "border-purple-500/30 text-purple-200 bg-transparent"
                      }`}
                    >
                      {isSpeaking ? <VolumeX className="h-4 w-4 mr-2" /> : <Volume2 className="h-4 w-4 mr-2" />}
                      {isSpeaking ? "Mute" : "Speaker"}
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                      placeholder="Ask GENIUS anything..."
                      className="bg-black/40 border-purple-500/30 text-white placeholder:text-purple-300"
                      disabled={isProcessing}
                    />
                    <Button
                      onClick={() => handleSendMessage()}
                      disabled={isProcessing || !message.trim()}
                      className="bg-purple-500 hover:bg-purple-600"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </Card>
        </div>
      )}
    </>
  )
}
