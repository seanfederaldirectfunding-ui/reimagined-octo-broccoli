"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Clock, CheckCircle, XCircle } from "lucide-react"

export function Applications() {
  const applications = [
    { id: 1, name: "John Smith - Business Loan", status: "approved", date: "Dec 20, 2024", amount: "$50,000" },
    { id: 2, name: "Sarah Johnson - Grant Application", status: "pending", date: "Dec 22, 2024", amount: "$25,000" },
    { id: 3, name: "Mike Davis - Equipment Financing", status: "review", date: "Dec 23, 2024", amount: "$35,000" },
    { id: 4, name: "Emily Brown - Working Capital", status: "rejected", date: "Dec 19, 2024", amount: "$40,000" },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4" />
      case "pending":
        return <Clock className="h-4 w-4" />
      case "review":
        return <FileText className="h-4 w-4" />
      case "rejected":
        return <XCircle className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-500/20 text-green-400 border-green-400/30"
      case "pending":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-400/30"
      case "review":
        return "bg-blue-500/20 text-blue-400 border-blue-400/30"
      case "rejected":
        return "bg-red-500/20 text-red-400 border-red-400/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-400/30"
    }
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Applications</h2>
      <div className="space-y-4">
        {applications.map((app) => (
          <Card key={app.id} className="bg-white/5 border-white/10 p-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="font-semibold text-white mb-2">{app.name}</h3>
                <div className="flex items-center gap-4 text-sm text-white/60">
                  <span>{app.date}</span>
                  <span className="font-semibold text-cyan-400">{app.amount}</span>
                </div>
              </div>
              <Badge className={`${getStatusColor(app.status)} flex items-center gap-2`}>
                {getStatusIcon(app.status)}
                {app.status}
              </Badge>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
