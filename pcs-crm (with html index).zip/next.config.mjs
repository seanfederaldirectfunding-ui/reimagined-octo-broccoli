/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  
  distDir: 'out',
  
  typescript: {
    ignoreBuildErrors: false,
  },
  
  eslint: {
    ignoreDuringBuilds: false,
  },
  
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  
  env: {
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL || 'https://pcs-pcrm.com',
  },
  
  async rewrites() {
    return []
  },
}

export default nextConfig
