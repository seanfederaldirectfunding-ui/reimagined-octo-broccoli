# Netlify Deployment Guide for PAGE CRM

## Prerequisites
- GitHub account with PCS-PCRM.COM-UPDATED repository
- Netlify account (free tier works perfectly)
- Your app is fully configured and working

## Step-by-Step Deployment Instructions

### Step 1: Create Netlify Account
1. Go to: https://www.netlify.com/
2. Click "Sign up" (top right)
3. Choose "Sign up with GitHub" (recommended)
4. Authorize Netlify to access your GitHub

### Step 2: Import Your Repository
1. After login, click "Add new site" → "Import an existing project"
2. Click "Deploy with GitHub"
3. Authorize Netlify if prompted
4. Find and select: `seanfederaldirectfunding-ui/PCS-PCRM.COM-UPDATED`
5. Click on the repository

### Step 3: Configure Build Settings
Netlify should auto-detect Next.js. Verify these settings:

**Build Settings:**
- **Base directory:** (leave empty)
- **Build command:** `npm run build`
- **Publish directory:** `.next`
- **Functions directory:** (leave empty)

**Advanced Settings:**
- **Node version:** 18.17.0 (auto-detected from package.json)
- **Package manager:** npm

### Step 4: Add Environment Variables
Before deploying, add your environment variables:

1. Click "Add environment variables"
2. Add each variable:

\`\`\`
NEXT_PUBLIC_VOIP_SERVER = [your VoIP server]
NEXT_PUBLIC_VOIP_USERNAME = [your VoIP username]
MAILGUN_API_KEY = 2d9c7386bb7d9b810b322c9f89baeb80-653fadca-da66fd39
MAILGUN_DOMAIN = [your Mailgun domain]
WHATSAPP_PHONE_NUMBER_ID = [your WhatsApp ID]
SIGNAL_PHONE_NUMBER = [your Signal number]
NEXT_PUBLIC_APP_URL = https://pcs-pcrm.com
\`\`\`

3. Click "Deploy site"

### Step 5: Wait for Build
- Build takes 2-4 minutes
- Watch the build logs for any errors
- When complete, you'll see "Site is live"

### Step 6: Get Your Netlify URL
After successful deployment:
- You'll get a URL like: `https://amazing-name-123456.netlify.app`
- Click "Visit site" to test

### Step 7: Connect Your Custom Domain (pcs-pcrm.com)

#### Option A: Use Netlify DNS (Recommended)
1. In Netlify dashboard, go to "Domain settings"
2. Click "Add custom domain"
3. Enter: `pcs-pcrm.com`
4. Click "Verify"
5. Netlify will show you name servers like:
   \`\`\`
   dns1.p01.nsone.net
   dns2.p01.nsone.net
   dns3.p01.nsone.net
   dns4.p01.nsone.net
   \`\`\`
6. Go to GoDaddy → Domain Settings → Name Servers
7. Click "Change Nameservers"
8. Select "Enter my own nameservers"
9. Add all 4 Netlify nameservers
10. Click "Save"
11. Wait 24-48 hours for DNS propagation

#### Option B: Keep GoDaddy DNS (Faster)
1. In Netlify, add domain `pcs-pcrm.com`
2. Netlify will show DNS records:
   \`\`\`
   A Record: @ → 75.2.60.5
   CNAME: www → [your-site].netlify.app
   \`\`\`
3. Go to GoDaddy → DNS Management
4. Add/Update these records:
   - Type: A, Name: @, Value: 75.2.60.5
   - Type: CNAME, Name: www, Value: [your-site].netlify.app
5. Save changes
6. Wait 1-2 hours for DNS propagation

### Step 8: Enable HTTPS
1. In Netlify → Domain settings
2. Click "HTTPS" tab
3. Click "Verify DNS configuration"
4. Click "Provision certificate"
5. Wait 1-2 minutes for SSL certificate

### Step 9: Test Your Site
1. Visit: https://pcs-pcrm.com
2. Test login: sean.federaldirectfunding.@gmail.com / Rasta4iva!
3. Test all features:
   - Dialer
   - Soft Phone
   - Lead Management
   - Messaging
   - Analytics

## Automatic Deployments
Every time you push to GitHub, Netlify automatically:
- Detects the change
- Builds your app
- Deploys the update
- Takes 2-4 minutes

## Troubleshooting

### Build Fails
1. Check build logs in Netlify dashboard
2. Verify all environment variables are set
3. Ensure Node version is 18.17.0+

### 404 Errors
1. Check netlify.toml is in repository root
2. Verify publish directory is `.next`
3. Clear cache and redeploy

### Domain Not Working
1. Verify DNS records in GoDaddy
2. Wait for DNS propagation (up to 48 hours)
3. Check domain settings in Netlify

## Netlify Features You Get (FREE)
- Automatic HTTPS/SSL
- Global CDN
- Automatic deployments from GitHub
- Deploy previews for pull requests
- Rollback to previous versions
- 100GB bandwidth/month
- 300 build minutes/month

## Support
- Netlify Docs: https://docs.netlify.com/
- Netlify Support: https://www.netlify.com/support/

## Next Steps After Deployment
1. Set up custom domain
2. Enable HTTPS
3. Configure email notifications
4. Set up deploy notifications
5. Add team members if needed

Your PAGE CRM will be live at https://pcs-pcrm.com with all features working!
